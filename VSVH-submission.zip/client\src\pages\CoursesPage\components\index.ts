export { CoursesPageContent } from './CoursesPageContent';
