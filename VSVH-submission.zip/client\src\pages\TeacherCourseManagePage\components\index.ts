export { TeacherCourseManagePageContent } from './TeacherCourseManagePageContent';
