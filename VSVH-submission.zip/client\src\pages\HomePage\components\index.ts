export { HomePageContent } from './HomePageContent';
