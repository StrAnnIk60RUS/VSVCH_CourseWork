export { TeacherCoursesPageContent } from './TeacherCoursesPageContent';
