export { RegisterPageContent } from './RegisterPageContent';
