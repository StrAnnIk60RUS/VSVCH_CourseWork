export { CourseDetailPageContent } from './CourseDetailPageContent';
