export { FavoritesPageContent } from './FavoritesPageContent';
