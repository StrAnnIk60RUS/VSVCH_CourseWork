export { TeacherCourseNewPageContent } from './TeacherCourseNewPageContent';
