export { CourseReviewsPageContent } from './CourseReviewsPageContent';
